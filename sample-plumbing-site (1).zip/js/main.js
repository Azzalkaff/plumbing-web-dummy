/* Shared behavior: navigation, services dropdown, accordions, contact form. */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  var DESKTOP_QUERY = '(min-width: 1024px)';

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  /* ---------- Navigation and dropdown ---------- */

  function initNav() {
    var toggle = document.querySelector('.nav-toggle');
    var panel = document.getElementById('site-nav');
    var item = document.querySelector('.has-dropdown');
    var desktop = window.matchMedia(DESKTOP_QUERY);
    var btn = null;
    var menu = null;
    var links = [];
    var closeTimer = null;
    var focusingProgrammatically = false;

    function focusEl(el) {
      focusingProgrammatically = true;
      el.focus();
      focusingProgrammatically = false;
    }

    function setPanel(open) {
      if (!toggle || !panel) { return; }
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      panel.classList.toggle('is-open', open);
    }

    function panelIsOpen() {
      return !!toggle && toggle.getAttribute('aria-expanded') === 'true';
    }

    function setDropdown(open) {
      if (!item || !btn) { return; }
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    }

    function dropdownIsOpen() {
      return !!item && item.classList.contains('is-open');
    }

    if (toggle && panel) {
      toggle.addEventListener('click', function () {
        setPanel(!panelIsOpen());
      });
    }

    if (item) {
      btn = item.querySelector('.dropdown-toggle');
      menu = item.querySelector('.dropdown');
      links = menu ? Array.prototype.slice.call(menu.querySelectorAll('a')) : [];
    }

    if (item && btn && menu) {
      btn.addEventListener('click', function () {
        setDropdown(!dropdownIsOpen());
      });

      item.addEventListener('mouseenter', function () {
        if (!desktop.matches) { return; }
        window.clearTimeout(closeTimer);
        setDropdown(true);
      });

      item.addEventListener('mouseleave', function () {
        if (!desktop.matches) { return; }
        closeTimer = window.setTimeout(function () {
          var active = document.activeElement;
          var keyboardInside = item.contains(active) && active.matches(':focus-visible');
          if (!keyboardInside) { setDropdown(false); }
        }, 150);
      });

      item.addEventListener('focusin', function (e) {
        if (!desktop.matches || focusingProgrammatically) { return; }
        if (e.target.matches && e.target.matches(':focus-visible')) {
          window.clearTimeout(closeTimer);
          setDropdown(true);
        }
      });

      item.addEventListener('focusout', function (e) {
        if (!desktop.matches) { return; }
        var next = e.relatedTarget;
        if (next && item.contains(next)) { return; }
        setDropdown(false);
      });

      item.addEventListener('keydown', function (e) {
        var key = e.key;
        var index = links.indexOf(document.activeElement);
        var inMenu = index !== -1;

        if (key === 'Escape') {
          if (dropdownIsOpen()) {
            setDropdown(false);
            focusEl(btn);
            e.stopPropagation();
          }
          return;
        }

        if (key === 'ArrowDown') {
          e.preventDefault();
          if (!dropdownIsOpen()) { setDropdown(true); }
          if (inMenu) {
            links[(index + 1) % links.length].focus();
          } else if (links.length) {
            links[0].focus();
          }
        } else if (key === 'ArrowUp' && inMenu) {
          e.preventDefault();
          if (index === 0) {
            btn.focus();
          } else {
            links[index - 1].focus();
          }
        } else if (key === 'Home' && inMenu) {
          e.preventDefault();
          links[0].focus();
        } else if (key === 'End' && inMenu) {
          e.preventDefault();
          links[links.length - 1].focus();
        }
      });

      document.addEventListener('click', function (e) {
        if (desktop.matches && dropdownIsOpen() && !item.contains(e.target)) {
          setDropdown(false);
        }
      });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && panelIsOpen() && !desktop.matches) {
        setPanel(false);
        if (toggle) { toggle.focus(); }
      }
    });

    function onBreakpointChange() {
      setPanel(false);
      setDropdown(false);
    }

    if (desktop.addEventListener) {
      desktop.addEventListener('change', onBreakpointChange);
    } else if (desktop.addListener) {
      desktop.addListener(onBreakpointChange);
    }
  }

  /* ---------- Accordions ---------- */

  function initAccordions() {
    var triggers = document.querySelectorAll('.accordion-trigger');
    Array.prototype.forEach.call(triggers, function (trigger) {
      trigger.addEventListener('click', function () {
        var expanded = trigger.getAttribute('aria-expanded') === 'true';
        var panel = document.getElementById(trigger.getAttribute('aria-controls'));
        trigger.setAttribute('aria-expanded', String(!expanded));
        if (panel) { panel.hidden = expanded; }
      });
    });
  }

  /* ---------- Contact form ---------- */

  function initForm() {
    var form = document.querySelector('[data-contact-form]');
    if (!form) { return; }

    var endpoint = (form.getAttribute('data-endpoint') || '').trim();
    var submitBtn = form.querySelector('button[type="submit"]');
    var submitLabel = submitBtn ? submitBtn.textContent : '';
    var successBox = document.getElementById('form-success');
    var errorBox = document.getElementById('form-error');

    var rules = {
      name: function (value) {
        return value.trim() ? '' : 'Please enter your name.';
      },
      email: function (value) {
        var v = value.trim();
        if (!v) { return 'Please enter your email address.'; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
          return 'Please enter a valid email address, for example name@example.com.';
        }
        return '';
      },
      message: function (value) {
        return value.trim() ? '' : 'Please enter a message.';
      }
    };

    function fieldParts(key) {
      return {
        input: document.getElementById('contact-' + key),
        error: document.getElementById('contact-' + key + '-error')
      };
    }

    function showError(key, message) {
      var parts = fieldParts(key);
      parts.error.textContent = message;
      parts.error.classList.add('is-visible');
      parts.input.setAttribute('aria-invalid', 'true');
      parts.input.setAttribute('aria-describedby', parts.error.id);
    }

    function clearError(key) {
      var parts = fieldParts(key);
      parts.error.textContent = '';
      parts.error.classList.remove('is-visible');
      parts.input.removeAttribute('aria-invalid');
      parts.input.removeAttribute('aria-describedby');
    }

    function validateField(key) {
      var message = rules[key](fieldParts(key).input.value);
      if (message) { showError(key, message); } else { clearError(key); }
      return !message;
    }

    Object.keys(rules).forEach(function (key) {
      var input = fieldParts(key).input;
      input.addEventListener('blur', function () {
        if (input.value !== '' || input.hasAttribute('aria-invalid')) { validateField(key); }
      });
      input.addEventListener('input', function () {
        if (input.hasAttribute('aria-invalid')) { validateField(key); }
      });
    });

    function hideMessages() {
      successBox.hidden = true;
      errorBox.hidden = true;
    }

    function showSuccess() {
      form.reset();
      errorBox.hidden = true;
      successBox.hidden = false;
      successBox.focus();
    }

    function showFailure() {
      successBox.hidden = true;
      errorBox.hidden = false;
      errorBox.focus();
    }

    function setSending(sending) {
      if (!submitBtn) { return; }
      submitBtn.disabled = sending;
      submitBtn.textContent = sending ? 'Sending...' : submitLabel;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      hideMessages();

      var firstInvalid = null;
      Object.keys(rules).forEach(function (key) {
        if (!validateField(key) && !firstInvalid) {
          firstInvalid = fieldParts(key).input;
        }
      });

      if (firstInvalid) {
        firstInvalid.focus();
        return;
      }

      if (!endpoint) {
        showSuccess();
        return;
      }

      setSending(true);
      fetch(endpoint, {
        method: 'POST',
        headers: { 'Accept': 'application/json' },
        body: new FormData(form)
      }).then(function (response) {
        if (!response.ok) { throw new Error('Request failed: ' + response.status); }
        setSending(false);
        showSuccess();
      }).catch(function () {
        setSending(false);
        showFailure();
      });
    });
  }

  ready(function () {
    initNav();
    initAccordions();
    initForm();
  });
})();
