/* Pexels image loader.
   Fills every <img data-pexels-query="..." data-pexels-fallback="..."> slot.
   Results are cached in localStorage for 7 days. Everything is wrapped so the
   page still works when storage is blocked or a request fails. */

(function () {
  'use strict';

  var API_KEY = 'YOUR_PEXELS_API_KEY';

  var API_URL = 'https://api.pexels.com/v1/search';
  var CACHE_PREFIX = 'pexels-cache-v1:';
  var CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
  var PER_PAGE = 8;
  var STOP_WORDS = ['with', 'and', 'the', 'for', 'from', 'into', 'near', 'over'];

  var requests = {};
  var usedIds = {};

  function hasKey() {
    return !!API_KEY && API_KEY !== 'YOUR_PEXELS_API_KEY';
  }

  function cacheKey(query) {
    return CACHE_PREFIX + query.toLowerCase().trim();
  }

  function readCache(query) {
    try {
      var raw = window.localStorage.getItem(cacheKey(query));
      if (!raw) { return null; }
      var entry = JSON.parse(raw);
      if (!entry || typeof entry.t !== 'number' || !Array.isArray(entry.photos)) { return null; }
      if (Date.now() - entry.t > CACHE_TTL_MS) {
        window.localStorage.removeItem(cacheKey(query));
        return null;
      }
      return entry.photos;
    } catch (err) {
      return null;
    }
  }

  function writeCache(query, photos) {
    try {
      window.localStorage.setItem(cacheKey(query), JSON.stringify({ t: Date.now(), photos: photos }));
    } catch (err) {
      /* storage blocked or full: ignore */
    }
  }

  function simplify(photo) {
    if (!photo || !photo.src || !photo.src.large) { return null; }
    return {
      id: photo.id,
      alt: photo.alt || '',
      large: photo.src.large,
      large2x: photo.src.large2x || ''
    };
  }

  function search(query) {
    if (requests[query]) { return requests[query]; }

    var cached = readCache(query);
    if (cached) {
      requests[query] = Promise.resolve(cached);
      return requests[query];
    }

    if (!hasKey() || typeof fetch !== 'function') {
      requests[query] = Promise.resolve([]);
      return requests[query];
    }

    var url = API_URL + '?query=' + encodeURIComponent(query) +
      '&per_page=' + PER_PAGE + '&orientation=landscape';

    requests[query] = fetch(url, { headers: { Authorization: API_KEY } })
      .then(function (response) {
        if (!response.ok) { throw new Error('Pexels request failed: ' + response.status); }
        return response.json();
      })
      .then(function (data) {
        var photos = (data.photos || []).map(simplify).filter(Boolean);
        writeCache(query, photos);
        return photos;
      })
      .catch(function () {
        return [];
      });

    return requests[query];
  }

  function tokens(text) {
    return text.toLowerCase().split(/[^a-z]+/).filter(function (word) {
      return word.length > 3 && STOP_WORDS.indexOf(word) === -1;
    });
  }

  /* A photo is skipped only when Pexels gives alt text that shares no keyword
     stem with the query. Photos without alt text are accepted. */
  function matchesSubject(photo, queryTokens) {
    var alt = photo.alt.toLowerCase();
    if (!alt) { return true; }
    for (var i = 0; i < queryTokens.length; i++) {
      if (alt.indexOf(queryTokens[i].slice(0, 4)) !== -1) { return true; }
    }
    return false;
  }

  function pick(photos, queryTokens) {
    for (var i = 0; i < photos.length; i++) {
      var photo = photos[i];
      if (usedIds[photo.id]) { continue; }
      if (!matchesSubject(photo, queryTokens)) { continue; }
      return photo;
    }
    return null;
  }

  function markEmpty(img) {
    img.removeAttribute('srcset');
    img.removeAttribute('src');
    img.alt = '';
    img.classList.remove('is-loaded');
    if (img.parentElement) { img.parentElement.classList.add('is-empty'); }
  }

  function apply(img, photo) {
    var sizes = img.getAttribute('data-sizes');
    img.addEventListener('load', function () {
      img.classList.add('is-loaded');
    });
    img.addEventListener('error', function () {
      markEmpty(img);
    });
    if (sizes) { img.sizes = sizes; }
    if (photo.large2x) {
      img.srcset = photo.large + ' 940w, ' + photo.large2x + ' 1880w';
    }
    img.src = photo.large;
  }

  function fill(img) {
    var query = (img.getAttribute('data-pexels-query') || '').trim();
    var fallback = (img.getAttribute('data-pexels-fallback') || '').trim();
    if (!query) { markEmpty(img); return Promise.resolve(); }

    var queryTokens = tokens(query + ' ' + fallback);

    return search(query)
      .then(function (photos) {
        var chosen = pick(photos, queryTokens);
        if (chosen || !fallback) { return chosen; }
        return search(fallback).then(function (fallbackPhotos) {
          return pick(fallbackPhotos, queryTokens);
        });
      })
      .then(function (photo) {
        if (photo) {
          usedIds[photo.id] = true;
          apply(img, photo);
        } else {
          markEmpty(img);
        }
      })
      .catch(function () {
        markEmpty(img);
      });
  }

  function init() {
    var slots = Array.prototype.slice.call(document.querySelectorAll('img[data-pexels-query]'));
    if (!slots.length) { return; }

    /* Start every primary query at once, then assign photos in page order so
       two slots on one page never receive the same picture. */
    slots.forEach(function (img) {
      var query = (img.getAttribute('data-pexels-query') || '').trim();
      if (query) { search(query); }
    });

    slots.reduce(function (chain, img) {
      return chain.then(function () { return fill(img); });
    }, Promise.resolve());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
